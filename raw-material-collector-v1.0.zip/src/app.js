import {uid,today,safeURL,freshState,duplicate,referencePrice,kgPrice,bestQuote,selectRecords,updateRecord,validateBackup} from './core.js';
import {loadState,mutateState,subscribe} from './db.js';
let state=await loadState();
let filter={view:'all',categoryId:'',subcategoryId:'',query:'',source:'',sort:'recent',quoteSource:'webQuotes'};
let edit=null,detailId=null,importData=null;
const $=(s,root=document)=>root.querySelector(s);
const $$=(s,root=document)=>[...root.querySelectorAll(s)];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const date=v=>v?new Date(v).toLocaleDateString('zh-CN'):'';
const money=v=>Number(v).toLocaleString('zh-CN',{maximumFractionDigits:2});
const options=(values,current)=>values.map(v=>`<option value="${esc(typeof v==='object'?v.id:v)}" ${(typeof v==='object'?v.id:v)===current?'selected':''}>${esc(typeof v==='object'?v.name:v)}</option>`).join('');
const blankQuote=()=>({id:uid(),amount:'',currency:'CNY',unit:'',weightGrams:'',quantity:'',date:today(),notes:'',images:[]});
const newRecord=()=>({id:uid(),name:'',englishName:'',aliases:'',spec:'',minOrder:'',supplier:'',source:'手动录入',link:'',categoryId:'',subcategoryId:'',brand:'',isBrand:false,confirmed:false,notes:'',webQuotes:[],privateQuotes:[],images:[],history:[],pinned:false,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),deletedAt:null});
function toast(message){const el=$('#toast');el.textContent=message;el.style.display='block';clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.style.display='none',4500);}
async function change(fn){state=await mutateState(fn);render();if(detailId)showDetail(detailId);}
const categoryName=r=>{const c=state.categories.find(c=>c.id===r.categoryId);return [c?.name,c?.children.find(s=>s.id===r.subcategoryId)?.name].filter(Boolean).join(' / ')||'待整理';};
function quoteHTML(q){
  const p=referencePrice(q,state.rates),kg=kgPrice(q);
  return `<div class="quote-line">${p!=null?`<div class="price">¥ ${money(p)} <small>/ 公斤</small></div>`:'<div class="muted">暂不可换算</div>'}<div>${esc(q.amount)} ${esc(q.currency)} / ${esc(q.unit||'单位待确认')}</div><div class="muted">${q.weightGrams?`每计价单位 ${esc(q.weightGrams)} 克 · `:''}${esc(q.quantity||'采购条件未填写')}<br>${esc(q.date||'日期未填写')}${q.currency!=='CNY'&&p!=null?` · 汇率 ${esc(state.rates.date)}${isStale()?'（旧汇率）':''}`:''}${kg!=null&&q.currency!=='CNY'?`<br>原币 ${money(kg)} ${esc(q.currency)}/公斤`:''}</div></div>`;
}
function isStale(){return !state.rates.fetchedAt||Date.now()-Date.parse(state.rates.fetchedAt)>24*3600*1000;}
function recordQuotes(r,source){const qs=r[source]||[];const best=bestQuote(r,source,state.rates);return qs.length?qs.map(q=>`${best?.quote===q&&filter.sort==='price'&&filter.subcategoryId?'<span class="pill">排序依据</span>':''}${quoteHTML(q)}`).join(''):'<span class="muted">未询价</span>';}
function render(){
  const rows=selectRecords(state,filter),c=state.categories.find(c=>c.id===filter.categoryId);
  const title=filter.view==='trash'?'回收站':filter.view==='brand'?'品牌原料':filter.view==='pending'?'待整理':c?c.children.find(s=>s.id===filter.subcategoryId)?.name||c.name:'全部原料';
  $('#app').innerHTML=`<header><div class="logo">原</div><div><h1>原料采购收藏夹</h1><small>让原料资料与每一次报价有据可查</small></div><div class="header-actions"><button data-action="settings">设置与备份</button><button class="primary" data-action="add">＋ 手动新增</button></div></header><div class="layout"><nav>${[['all','全部原料'],['brand','品牌原料'],['pending','待整理']].map(([v,n])=>`<button data-view="${v}" class="${filter.view===v&&!c?'active':''}">${n}</button>`).join('')}<div class="nav-label">原料分类</div>${state.categories.map(cat=>`<button data-category="${cat.id}" class="${filter.categoryId===cat.id&&!filter.subcategoryId?'active':''}">${esc(cat.name)}</button>${cat.children.map(sub=>`<button class="sub ${filter.subcategoryId===sub.id?'active':''}" data-category="${cat.id}" data-subcategory="${sub.id}">${esc(sub.name)}</button>`).join('')}`).join('')}<button data-action="categories">＋ 管理分类</button><div class="nav-label">资料管理</div><button data-view="trash" class="${filter.view==='trash'?'active':''}">回收站</button></nav><main><div class="topline"><div><h2>${esc(title)}</h2><div class="muted">${rows.length} 条供应商记录 · 本机保存，无需账号</div></div><span class="pill">网页价 / 私下价 独立保留</span></div><div class="toolbar"><input id="search" placeholder="搜索中文名、英文名、别名、供应商…" value="${esc(filter.query)}" aria-label="搜索原料"><select id="source-filter" aria-label="来源筛选"><option value="">全部来源</option>${options(state.sources,filter.source)}</select><select id="sort" aria-label="排序"><option value="recent" ${filter.sort==='recent'?'selected':''}>最近收藏 · 置顶优先</option><option value="price" ${filter.sort==='price'?'selected':''}>人民币 / 公斤 从低到高</option></select><select id="quote-source" aria-label="比价来源"><option value="webQuotes" ${filter.quoteSource==='webQuotes'?'selected':''}>按网页价比价</option><option value="privateQuotes" ${filter.quoteSource==='privateQuotes'?'selected':''}>按私下价比价</option></select></div>${filter.sort==='price'&&!filter.subcategoryId?'<div class="notice">请先从左侧选择同规格小类，再进行价格排序。当前按最近收藏显示。</div>':''}<div class="panel">${rows.length?`<table><thead><tr><th>原料 / 规格</th><th>供应商 / 来源</th><th>网页价</th><th>私下报价</th><th>管理</th></tr></thead><tbody>${rows.map(r=>`<tr><td><strong>${r.pinned?'★ ':''}${esc(r.name)}</strong><div>${esc(r.spec||'规格待确认')}</div><div class="muted">${esc(r.englishName||'')}</div><span class="pill">${esc(categoryName(r))}</span>${r.isBrand?`<span class="pill">${esc(r.brand||'品牌原料')}</span>`:''}${!r.confirmed?'<span class="pill">待确认</span>':''}<div class="muted">收藏 ${date(r.createdAt)}</div></td><td><strong>${esc(r.supplier||'供应商待补充')}</strong><span class="muted">${esc(r.source)}<br>起订量：${esc(r.minOrder||'待补充')}</span></td><td>${recordQuotes(r,'webQuotes')}</td><td>${recordQuotes(r,'privateQuotes')}</td><td class="nowrap"><button data-detail="${r.id}">详情${r.images?.length||r.notes?' · 资料':''}</button>${filter.view==='trash'?`<button data-restore="${r.id}">恢复</button><button class="danger" data-purge="${r.id}">彻底删除</button>`:`<br><button data-edit="${r.id}">编辑</button><button data-pin="${r.id}">${r.pinned?'取消置顶':'置顶'}</button><br>${safeURL(r.link)?`<a href="${esc(safeURL(r.link))}" target="_blank" rel="noopener noreferrer">打开购买页 ↗</a><br>`:''}<button class="danger" data-delete="${r.id}">移入回收站</button>`}</td></tr>`).join('')}</tbody></table>`:`<div class="empty"><div class="symbol">▧</div><h3>${filter.query?'没有找到匹配的原料':'这里还没有原料记录'}</h3><p class="muted">打开商品页面，点击浏览器扩展收藏；也可以手动添加私下报价。</p>${filter.view==='trash'?'':'<button class="primary" data-action="add">添加第一条原料</button>'}</div>`}</div><footer>只有规格已确认且完成分类的记录参与同规格比价。重量与汇率不明时保留原价，不按零元排序。</footer></main></div>`;
}
function showDetail(id){
  $('.detail')?.remove();const r=state.records.find(r=>r.id===id);if(!r){detailId=null;return;}detailId=id;
  const el=document.createElement('aside');el.className='detail';el.setAttribute('aria-label','原料详情');
  el.innerHTML=`<button class="detail-close" data-action="close-detail">关闭</button><span class="muted">原料档案</span><h2>${esc(r.name)}</h2><p>${esc(r.spec||'规格待确认')}</p><dl>${[['英文名',r.englishName],['别名',r.aliases],['分类',categoryName(r)],['供应商',r.supplier],['来源',r.source],['起订量',r.minOrder],['品牌',r.brand],['收藏日期',date(r.createdAt)],['更新日期',date(r.updatedAt)]].map(([k,v])=>`<dt>${k}</dt><dd>${esc(v||'—')}</dd>`).join('')}</dl><h3>最新网页报价</h3>${recordQuotes(r,'webQuotes')}<h3>最新私下报价</h3>${recordQuotes(r,'privateQuotes')}${(r.privateQuotes||[]).map(q=>`<p>${esc(q.notes||'')}</p>${imageHTML(q.images||[])}`).join('')}<h3>备注与截图</h3><p style="white-space:pre-wrap">${esc(r.notes||'暂无备注')}</p>${imageHTML(r.images||[])}<details><summary>历史报价（${r.history.length} 次）</summary>${r.history.slice().reverse().map(h=>`<h4>${h.source==='webQuotes'?'网页价':'私下价'} · 归档 ${date(h.archivedAt)}</h4>${h.quotes.map(q=>quoteHTML(q)+`<p>${esc(q.notes||'')}</p>`+imageHTML(q.images||[])).join('')}`).join('')||'<p class="muted">暂无历史报价。汇率刷新不会生成报价历史。</p>'}</details>${safeURL(r.link)?`<a href="${esc(safeURL(r.link))}" target="_blank" rel="noopener noreferrer">打开购买页 ↗</a>`:''}${!r.deletedAt?`<p><button class="primary" data-edit="${r.id}">编辑资料与报价</button></p>`:''}`;
  document.body.append(el);
}
function imageHTML(images,removePrefix=''){return `<div class="images">${images.map((img,i)=>`<div class="image-item"><a href="${esc(img.data)}" target="_blank" rel="noopener noreferrer"><img src="${esc(img.data)}" alt="${esc(img.name)}"></a>${removePrefix?`<button type="button" data-image-remove="${removePrefix}:${i}">移除</button>`:''}</div>`).join('')}</div>`;}
function input(label,name,value,type='text',extra=''){return `<label>${label}<input type="${type}" data-field="${name}" value="${esc(value)}" ${extra}></label>`;}
function openEditor(record=null,draft=null){
  const base=record?structuredClone(record):{...newRecord(),name:draft?.name||'',supplier:draft?.supplier||'',source:draft?.source||'手动录入',link:safeURL(draft?.link||'')};
  edit={base,existingId:record?.id||null,warning:draft?.warning||'',rows:record?[{...base,selected:true,subcategoryName:state.categories.find(c=>c.id===base.categoryId)?.children.find(s=>s.id===base.subcategoryId)?.name||''}]:draft?.specs?.length?draft.specs.map(s=>({...newRecord(),...base,id:uid(),spec:s.spec||'',minOrder:s.quantity||'',selected:!!s.selected,subcategoryName:'',webQuotes:s.amount?[{...blankQuote(),amount:s.amount,currency:s.currency||'CNY',unit:s.unit||'',weightGrams:s.weightGrams||'',quantity:s.quantity||''}]:[],privateQuotes:[],images:[],notes:'',confirmed:false})):[{...base,selected:true,subcategoryName:''}]};
  renderEditor();$('#editor').showModal();
}
function renderEditor(){
  const b=edit.base;
  $('#editor').innerHTML=`<form id="record-form"><h2>${edit.existingId?'编辑原料与报价':'收藏原料'}</h2><p class="muted">检查信息后确认保存。取消将丢弃本次修改。</p>${edit.warning?`<div class="notice">${esc(edit.warning)}</div>`:''}<div id="form-error" class="error" role="alert"></div><div class="grid">${input('原料名称 *','name',b.name)}${input('英文名称','englishName',b.englishName)}${input('别名（可填写多个）','aliases',b.aliases)}${input('供应商','supplier',b.supplier)}<label>来源平台<input data-field="source" list="source-list" value="${esc(b.source)}"><datalist id="source-list">${options(state.sources,'')}</datalist></label>${input('购买链接（可留空）','link',b.link,'url')}<label>原料大类<select data-field="categoryId"><option value="">待整理 / 未分类</option>${options(state.categories,b.categoryId)}</select></label>${input('或新建大类','newCategory',b.newCategory||'')}${input('品牌名','brand',b.brand)}<label class="check"><input type="checkbox" data-field="isBrand" ${b.isBrand?'checked':''}> 品牌原料（保留普通分类）</label></div><div class="section-title"><strong>规格与对应报价</strong><div><button type="button" data-action="select-all">全选</button> <button type="button" data-action="add-spec" ${edit.existingId?'disabled':''}>＋ 添加规格</button></div></div>${edit.rows.map((r,i)=>specHTML(r,i)).join('')}<div class="form-footer"><button type="button" data-action="cancel-edit">取消</button><button type="submit" class="primary">确认保存（${edit.rows.filter(r=>r.selected).length}）</button></div></form>`;
}
function specHTML(r,i){
  const d=duplicate(state.records,{...r,link:edit.base.link});
  return `<section class="spec-row" data-row="${i}"><div class="spec-header"><input type="checkbox" aria-label="选择此规格" data-row-field="selected" ${r.selected?'checked':''}><input type="text" data-row-field="spec" aria-label="规格名称" placeholder="规格，例如富里酸 5%" value="${esc(r.spec)}">${!edit.existingId?`<button type="button" data-remove-row="${i}">移除</button>`:''}</div>${d?`<div class="duplicates">已收藏${d.deletedAt?'（回收站）':''}：${esc(d.name)} · ${esc(d.spec)} · ${esc(d.supplier)} · ${esc(categoryName(d))} · ${date(d.createdAt)} <button type="button" data-detail="${d.id}">查看原记录</button></div>`:''}<div class="grid"><label>起订量（无报价也可保存）<input data-row-field="minOrder" value="${esc(r.minOrder||'')}" placeholder="例如 1 千克起批"></label><label>规格小类<input data-row-field="subcategoryName" list="sub-list-${i}" value="${esc(r.subcategoryName)}" placeholder="选择已有小类或输入新名称"><datalist id="sub-list-${i}">${options(state.categories.find(c=>c.id===edit.base.categoryId)?.children||[],'')}</datalist></label><label class="check"><input type="checkbox" data-row-field="confirmed" ${r.confirmed?'checked':''}> 已人工确认规格（参与同规格比价）</label><span class="muted">未明确重量时不要换算。单位“袋 / 桶”需要填每个计价单位的净重。</span></div><strong>网页普通标价 / 同规格阶梯价</strong>${quoteEditor(r.webQuotes,i,'webQuotes')}<button type="button" data-add-quote="${i}:webQuotes">＋ 添加价格档位</button><details ${r.privateQuotes.length?'open':''}><summary>此规格的私下报价与报价截图</summary>${quoteEditor(r.privateQuotes,i,'privateQuotes')}<button type="button" data-add-quote="${i}:privateQuotes">＋ 添加私下报价</button></details><label>此规格备注<textarea data-row-field="notes">${esc(r.notes)}</textarea></label><p class="muted">截图属于此规格。私下报价的截图请上传至上面的对应报价档位。</p><label>上传此规格截图<input type="file" accept="image/png,image/jpeg,image/webp,image/gif" multiple data-upload="${i}:record"></label>${imageHTML(r.images,`${i}:record`)}</section>`;
}
function quoteEditor(qs,i,source){return qs.map((q,j)=>`<div data-quote="${i}:${source}:${j}"><div class="quote-editor">${input('金额','amount',q.amount,'number','step="any" min="0.000001"')}<label>币种<input data-field="currency" value="${esc(q.currency)}" maxlength="3" list="currencies-${i}-${source}"></label>${input('计价单位','unit',q.unit)}${input('每单位净重(克)','weightGrams',q.weightGrams,'number','step="any" min="0.000001"')}${input('起订量 / 采购条件','quantity',q.quantity)}${input('报价日期','date',q.date,'date')}<button type="button" data-remove-quote="${i}:${source}:${j}" aria-label="删除报价">×</button></div><div class="quote-extra"><label>报价备注<textarea data-field="notes">${esc(q.notes||'')}</textarea></label><label>对应此档报价的截图（此区域可粘贴图片）<input type="file" accept="image/png,image/jpeg,image/webp,image/gif" multiple data-upload="${i}:${source}:${j}"></label>${imageHTML(q.images||[],`${i}:${source}:${j}`)}</div></div>`).join('')+'<datalist id="currencies-${i}-${source}"><option>CNY</option><option>USD</option><option>EUR</option><option>GBP</option><option>JPY</option><option>AUD</option><option>CAD</option><option>CHF</option><option>HKD</option></datalist>';}
function syncEditor(){
  if(!edit)return;
  $$('#record-form > .grid [data-field]').forEach(el=>{edit.base[el.dataset.field]=el.type==='checkbox'?el.checked:el.value;});
  $$('.spec-row').forEach(section=>{
    const r=edit.rows[Number(section.dataset.row)];
    $$('[data-row-field]',section).forEach(el=>{r[el.dataset.rowField]=el.type==='checkbox'?el.checked:el.value;});
    $$('[data-quote]',section).forEach(qel=>{const [,source,j]=qel.dataset.quote.split(':');$$('[data-field]',qel).forEach(el=>{r[source][j][el.dataset.field]=el.value;});});
  });
}
async function saveEditor(event){
  event.preventDefault();syncEditor();const selected=edit.rows.filter(r=>r.selected);
  try{
    if(!edit.base.name.trim())throw new Error('请填写原料名称');
    if(!selected.length)throw new Error('请选择至少一个规格；没有明确选中规格时请自行勾选。');
    if(edit.base.link&&!safeURL(edit.base.link))throw new Error('购买链接必须为 HTTP 或 HTTPS 链接');
    for(const r of selected){
      if(r.confirmed&&!r.spec.trim())throw new Error('确认规格前请填写规格名称');
      for(const source of ['webQuotes','privateQuotes'])for(const q of r[source]){
        if(!Number.isFinite(Number(q.amount))||Number(q.amount)<=0)throw new Error('报价金额需大于零；没有价格请移除空档位。');
        if(q.weightGrams!==''&&(!Number.isFinite(Number(q.weightGrams))||Number(q.weightGrams)<=0))throw new Error('净重需大于零，未知时留空。');
        q.currency=q.currency.toUpperCase().trim();if(!/^[A-Z]{3}$/.test(q.currency))throw new Error('币种请填写三位代码，例如 CNY、USD。');
      }
    }
    let savedIds=[];
    await change(s=>{
      let cat=s.categories.find(c=>c.id===edit.base.categoryId);
      if(edit.base.newCategory?.trim()){cat=s.categories.find(c=>c.name===edit.base.newCategory.trim());if(!cat){cat={id:uid(),name:edit.base.newCategory.trim(),children:[]};s.categories.push(cat);}}
      const pending=[];
      for(const row of selected){
        const {selected,subcategoryName,...rowData}=row;
        const {newCategory,...base}=edit.base;
        const r={...rowData,...Object.fromEntries(['name','englishName','aliases','supplier','source','link','brand','isBrand'].map(k=>[k,base[k]])),categoryId:cat?.id||'',subcategoryId:''};
        if(cat&&row.subcategoryName.trim()){
          let sub=cat.children.find(c=>c.name===row.subcategoryName.trim());if(!sub){sub={id:uid(),name:row.subcategoryName.trim()};cat.children.push(sub);}r.subcategoryId=sub.id;
        }
        const dupe=duplicate([...s.records,...pending],r);
        if(dupe)throw new Error(`此商品规格已经收藏：${dupe.name} / ${dupe.spec||'规格待确认'}。请打开原记录更新，或从回收站恢复。`);
        r.updatedAt=new Date().toISOString();
        if(edit.existingId){const previous=s.records.find(x=>x.id===edit.existingId);if(!previous||previous.deletedAt)throw new Error('原记录已删除，请关闭编辑窗口后重新打开。');pending.push(updateRecord(previous,r));}
        else pending.push(r);
      }
      for(const r of pending){const index=s.records.findIndex(x=>x.id===r.id);if(index>=0)s.records[index]=r;else s.records.push(r);savedIds.push(r.id);if(r.source&&!s.sources.includes(r.source))s.sources.push(r.source);}
    });
    $('#editor').close();edit=null;toast(`已保存 ${savedIds.length} 条规格记录`);
  }catch(e){$('#form-error').textContent=e.message;$('#form-error').scrollIntoView({block:'nearest'});}
}
async function addImages(target,files){
  syncEditor();let images;if(target[1]==='record')images=edit.rows[target[0]].images;else images=edit.rows[target[0]][target[1]][target[2]].images;
  try{
    for(const file of files){
      if(!['image/png','image/jpeg','image/webp','image/gif'].includes(file.type))throw new Error('仅支持 PNG、JPEG、WebP、GIF 截图');
      if(file.size>10*1024*1024)throw new Error('单张截图不能超过 10MB');
      const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(reader.error);reader.readAsDataURL(file);});
      images.push({id:uid(),name:file.name||'粘贴截图.png',data,createdAt:new Date().toISOString()});
    }
    renderEditor();
  }catch(e){toast(e.message);}
}
function openSettings(){renderSettings();$('#settings').showModal();}
function renderSettings(){
  $('#settings').innerHTML=`<h2>设置与备份</h2><div id="settings-error" class="error" role="alert"></div><details open><summary>汇率 · 人民币参考价</summary><p class="muted">来源：open.er-api.com，基准 CNY。使用服务返回的汇率日期，保留原币原价。失败时保留旧汇率并标注日期。${esc(state.rates.date?`当前日期 ${state.rates.date}${isStale()?'（旧汇率）':''}`:'尚未获取汇率，外币暂不可换算。')}</p><button data-action="rates">获取最新汇率</button><div class="rate-list muted">${Object.entries(state.rates.values).filter(([c])=>['USD','EUR','GBP','JPY','AUD','CAD','HKD'].includes(c)).map(([c,r])=>`${c}: 1 ${c} ≈ ${money(r)} CNY`).join(' · ')}</div></details><details open><summary>完整备份与恢复</summary><p class="muted">JSON 文件包含分类、记录、网页价、私下价、历史、备注、截图及回收站。备份含采购信息，请妥善保管。恢复会替换当前全部资料，先导出当前备份。</p><button data-action="export">导出完整备份</button><label>选择备份文件<input type="file" id="import-file" accept=".json,application/json"></label><div id="import-summary"></div></details><details id="category-settings" open><summary>大类与规格小类</summary><p class="muted">修改名称保留记录关联；删除被记录使用的分类前请先移动记录（包括回收站）。</p>${state.categories.map(c=>`<section class="spec-row"><div class="category-row"><input aria-label="大类名称" value="${esc(c.name)}" data-cat-name="${c.id}"><button data-rename-cat="${c.id}">改名</button><button data-delete-cat="${c.id}">删除大类</button></div>${c.children.map(s=>`<div class="category-row"><span>↳</span><input aria-label="小类名称" value="${esc(s.name)}" data-sub-name="${s.id}"><button data-rename-sub="${c.id}:${s.id}">改名</button><button data-delete-sub="${c.id}:${s.id}">删除小类</button></div>`).join('')}<div class="category-row"><input placeholder="新小类，例如元素镁14%" data-new-sub="${c.id}"><button data-add-sub="${c.id}">新增小类</button></div></section>`).join('')}<div class="category-row"><input id="new-category" placeholder="新大类，例如柠檬酸镁"><button data-action="add-category">新增大类</button></div></details><details><summary>来源平台</summary><p class="muted">${state.sources.map(esc).join(' · ')}。新增名称不会自动适配该网站。</p><div class="category-row"><input id="new-source" placeholder="新来源名称"><button data-action="add-source">新增来源</button></div></details><div class="form-footer"><button data-action="close-settings">完成</button></div>`;
}
async function refreshRates(){
  const button=$('[data-action="rates"]');button.disabled=true;button.textContent='正在获取…';
  try{
    const response=await fetch('https://open.er-api.com/v6/latest/CNY',{signal:AbortSignal.timeout(15000)});if(!response.ok)throw new Error(`接口返回 ${response.status}`);
    const data=await response.json();if(data.result!=='success'||data.base_code!=='CNY'||!data.rates)throw new Error('接口数据格式无效');
    const values={CNY:1};for(const [currency,rate] of Object.entries(data.rates))if(/^[A-Z]{3}$/.test(currency)&&Number.isFinite(rate)&&rate>0)values[currency]=1/rate;
    const timestamp=Number(data.time_last_update_unix);if(!Number.isFinite(timestamp)||timestamp<=0)throw new Error('接口缺少有效汇率日期');
    await change(s=>{s.rates={values,date:new Date(timestamp*1000).toISOString().slice(0,10),fetchedAt:new Date().toISOString()};});renderSettings();toast('汇率已更新；报价历史保持不变');
  }catch(e){$('#settings-error').textContent=`获取失败：${e.message}。${state.rates.date?`继续使用 ${state.rates.date} 的旧汇率。`:'外币暂不可换算。'}`;button.disabled=false;button.textContent='重试获取汇率';}
}
async function exportBackup(){const snapshot=await loadState();const blob=new Blob([JSON.stringify({...snapshot,exportedAt:new Date().toISOString()},null,2)],{type:'application/json'});const link=document.createElement('a');const url=URL.createObjectURL(blob);link.href=url;link.download=`原料采购备份-${today()}.json`;link.click();setTimeout(()=>URL.revokeObjectURL(url),5000);toast('已导出完整备份（包含截图）');}
async function importFile(file){
  importData=null;
  try{if(!file)return;if(file.size>200*1024*1024)throw new Error('备份文件超过 200MB');const data=validateBackup(JSON.parse(await file.text()));importData=data;$('#import-summary').innerHTML=`<div class="notice">已校验：${data.records.length} 条记录、${data.categories.length} 个大类。恢复会替换全部本机资料。<br><label class="check"><input id="import-confirm" type="checkbox"> 我已备份当前资料，确认替换</label><button class="danger" data-action="import">确认恢复</button></div>`;}catch(e){$('#settings-error').textContent=`导入失败：${e.message}`;$('#import-summary').textContent='';}
}
// Delegate interactions so UI rebuilds never retain stale event closures.
document.addEventListener('click',async event=>{
  const el=event.target.closest('button');if(!el)return;
  try{
    if(el.dataset.view){filter={...filter,view:el.dataset.view,categoryId:'',subcategoryId:''};render();}
    if(el.dataset.category){filter={...filter,view:'all',categoryId:el.dataset.category,subcategoryId:el.dataset.subcategory||''};render();}
    if(el.dataset.detail){showDetail(el.dataset.detail);}
    if(el.dataset.edit){const r=state.records.find(r=>r.id===el.dataset.edit);if(r&&!r.deletedAt)openEditor(r);}
    if(el.dataset.pin)await change(s=>{const r=s.records.find(r=>r.id===el.dataset.pin);r.pinned=!r.pinned;});
    if(el.dataset.delete){await change(s=>{s.records.find(r=>r.id===el.dataset.delete).deletedAt=new Date().toISOString();});toast('已移入回收站，可恢复');}
    if(el.dataset.restore){await change(s=>{s.records.find(r=>r.id===el.dataset.restore).deletedAt=null;});toast('已恢复');}
    if(el.dataset.purge&&confirm('彻底删除此记录、报价历史和截图？此操作无法撤销。')){await change(s=>{s.records=s.records.filter(r=>r.id!==el.dataset.purge);});toast('已彻底删除');}
    const a=el.dataset.action;
    if(a==='add')openEditor();
    if(a==='settings'||a==='categories')openSettings();
    if(a==='close-settings'){$('#settings').close();importData=null;}
    if(a==='close-detail'){$('.detail')?.remove();detailId=null;}
    if(a==='cancel-edit'){$('#editor').close();edit=null;}
    if(a==='add-spec'){syncEditor();edit.rows.push({...newRecord(),selected:false,subcategoryName:''});renderEditor();}
    if(a==='select-all'){syncEditor();edit.rows.forEach(r=>r.selected=true);renderEditor();}
    if(el.dataset.removeRow){syncEditor();edit.rows.splice(Number(el.dataset.removeRow),1);renderEditor();}
    if(el.dataset.addQuote){syncEditor();const [i,source]=el.dataset.addQuote.split(':');edit.rows[i][source].push(blankQuote());renderEditor();}
    if(el.dataset.removeQuote){syncEditor();const [i,source,j]=el.dataset.removeQuote.split(':');edit.rows[i][source].splice(Number(j),1);renderEditor();}
    if(el.dataset.imageRemove){syncEditor();const pieces=el.dataset.imageRemove.split(':');const last=Number(pieces.pop());const [i,source,j]=pieces;const images=source==='record'?edit.rows[i].images:edit.rows[i][source][j].images;images.splice(last,1);renderEditor();}
    if(a==='rates')await refreshRates();
    if(a==='export')await exportBackup();
    if(a==='import'){
      if(!importData||!$('#import-confirm')?.checked)throw new Error('请先勾选确认替换。');
      const snapshot=structuredClone(importData);await change(s=>{Object.keys(s).forEach(k=>delete s[k]);Object.assign(s,snapshot);});importData=null;filter={...filter,view:'all',categoryId:'',subcategoryId:''};render();renderSettings();toast('备份已完整恢复');
    }
    if(a==='add-source'){const name=$('#new-source').value.trim();if(!name)throw new Error('请填写来源名称');await change(s=>{if(!s.sources.includes(name))s.sources.push(name);});renderSettings();}
    if(a==='add-category'){const name=$('#new-category').value.trim();if(!name)throw new Error('请填写大类名称');await change(s=>{if(s.categories.some(c=>c.name===name))throw new Error('大类名称已存在');s.categories.push({id:uid(),name,children:[]});});renderSettings();}
    if(el.dataset.addSub){const id=el.dataset.addSub,name=$(`[data-new-sub="${id}"]`).value.trim();if(!name)throw new Error('请填写小类名称');await change(s=>{const cat=s.categories.find(c=>c.id===id);if(cat.children.some(c=>c.name===name))throw new Error('小类名称已存在');cat.children.push({id:uid(),name});});renderSettings();}
    if(el.dataset.renameCat){const id=el.dataset.renameCat,name=$(`[data-cat-name="${id}"]`).value.trim();if(!name)throw new Error('名称不能为空');await change(s=>{if(s.categories.some(c=>c.id!==id&&c.name===name))throw new Error('大类名称已存在');s.categories.find(c=>c.id===id).name=name;});renderSettings();}
    if(el.dataset.renameSub){const [id,sub]=el.dataset.renameSub.split(':'),name=$(`[data-sub-name="${sub}"]`).value.trim();if(!name)throw new Error('名称不能为空');await change(s=>{const cat=s.categories.find(c=>c.id===id);if(cat.children.some(c=>c.id!==sub&&c.name===name))throw new Error('小类名称已存在');cat.children.find(c=>c.id===sub).name=name;});renderSettings();}
    if(el.dataset.deleteCat){const id=el.dataset.deleteCat;await change(s=>{if(s.records.some(r=>r.categoryId===id))throw new Error('此分类仍有记录，请先移动记录。');s.categories=s.categories.filter(c=>c.id!==id);});if(filter.categoryId===id){filter.categoryId='';filter.subcategoryId='';render();}renderSettings();}
    if(el.dataset.deleteSub){const [id,sub]=el.dataset.deleteSub.split(':');await change(s=>{if(s.records.some(r=>r.subcategoryId===sub))throw new Error('此小类仍有记录，请先移动记录。');const cat=s.categories.find(c=>c.id===id);cat.children=cat.children.filter(c=>c.id!==sub);});if(filter.subcategoryId===sub){filter.subcategoryId='';render();}renderSettings();}
  }catch(e){toast(e.message);}
});
document.addEventListener('submit',event=>{if(event.target.id==='record-form')saveEditor(event);});
document.addEventListener('change',event=>{
  const el=event.target;
  if(el.id==='source-filter'){filter.source=el.value;render();}
  if(el.id==='sort'){filter.sort=el.value;render();}
  if(el.id==='quote-source'){filter.quoteSource=el.value;render();}
  if(el.dataset.upload)addImages(el.dataset.upload.split(':'),[...el.files]);
  if(el.id==='import-file')importFile(el.files[0]);
  if(el.dataset.field==='categoryId'&&edit){syncEditor();renderEditor();}
  if(el.dataset.rowField==='selected'&&edit){syncEditor();const count=edit.rows.filter(r=>r.selected).length;$('#record-form button[type="submit"]').textContent=`确认保存（${count}）`;}
});
document.addEventListener('input',event=>{
  if(event.target.id==='search'){const start=event.target.selectionStart;filter.query=event.target.value;render();$('#search').focus();$('#search').setSelectionRange(start,start);}
});
document.addEventListener('paste',event=>{
  if(!edit||!$('#editor').open)return;const files=[...event.clipboardData.items].filter(i=>i.kind==='file'&&i.type.startsWith('image/')).map(i=>i.getAsFile());if(!files.length)return;
  const section=event.target.closest('.spec-row');if(!section){toast('请先点击目标规格或报价区域，再粘贴截图。');return;}
  event.preventDefault();const q=event.target.closest('[data-quote]');addImages(q?q.dataset.quote.split(':'):[section.dataset.row,'record'],files);
});
$('#editor').addEventListener('cancel',()=>{edit=null;});
subscribe(async()=>{state=await loadState();render();if(detailId)showDetail(detailId);});
render();
const capture=new URLSearchParams(location.search).get('capture');
if(capture&&globalThis.chrome?.storage?.session){
  const result=await chrome.storage.session.get(capture);const draft=result[capture];if(draft){await chrome.storage.session.remove(capture);openEditor(null,draft);
    const keyRecord=state.records.find(r=>!r.deletedAt&&duplicate([r],{link:draft.link,spec:r.spec}));
    if(keyRecord){const banner=document.createElement('div');banner.className='notice';banner.innerHTML='此购买页已有收藏。更新仅替换网页报价，私下报价与备注保留。';
      const select=document.createElement('select');select.id='update-record';select.innerHTML=state.records.filter(r=>!r.deletedAt&&duplicate([r],{link:draft.link,spec:r.spec})).map(r=>`<option value="${r.id}">${esc(r.name)} / ${esc(r.spec||'待确认规格')}</option>`).join('');
      const button=document.createElement('button');button.type='button';button.textContent='更新这条记录的网页报价';button.onclick=()=>{
        const record=state.records.find(r=>r.id===select.value);const matching=draft.specs.find(s=>s.spec===record.spec);
        openEditor(record);edit.warning='正在更新网页报价，请确认新报价。其他资料沿用原记录。';
        if(matching?.amount)edit.rows[0].webQuotes=[{...blankQuote(),amount:matching.amount,currency:matching.currency||'CNY',unit:matching.unit||'',weightGrams:matching.weightGrams||'',quantity:matching.quantity||''}];
        else edit.warning+=' 未可靠识别此规格价格，已保留旧价，请手动修改。';renderEditor();
      };banner.append(select,button);$('#record-form').prepend(banner);
    }
  }else toast('收藏草稿已失效，请回到商品页重新点击扩展。');
}

// Automatic FX refresh only; supplier prices are never fetched in the background.
if(isStale()) {
  fetch('https://open.er-api.com/v6/latest/CNY',{signal:AbortSignal.timeout(15000)})
    .then(async response=>{if(!response.ok)throw new Error('汇率服务不可用');return response.json();})
    .then(async data=>{
      if(data.result!=='success'||data.base_code!=='CNY'||!data.rates||!Number.isFinite(data.time_last_update_unix)||data.time_last_update_unix<=0)return;
      const values={CNY:1};for(const [currency,rate] of Object.entries(data.rates))if(/^[A-Z]{3}$/.test(currency)&&Number.isFinite(rate)&&rate>0)values[currency]=1/rate;
      await change(s=>{s.rates={values,date:new Date(data.time_last_update_unix*1000).toISOString().slice(0,10),fetchedAt:new Date().toISOString()};});
    }).catch(()=>{});
}
