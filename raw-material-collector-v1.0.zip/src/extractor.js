// Runs only after the user clicks the extension. No polling or background scraping.
globalThis.__rawMaterialExtract = () => {
  const text=el=>(el?.textContent||'').replace(/\s+/g,' ').trim();
  const is1688=location.hostname==='1688.com'||location.hostname.endsWith('.1688.com');
  const draft={link:location.href,name:'',supplier:'',source:is1688?'1688':location.hostname,specs:[],warning:'自动识别仅供参考。请确认规格、普通标价、单位及起订量；没有明确所选规格时不会自动勾选。'};
  const objects=[];
  for(const script of document.querySelectorAll('script[type="application/ld+json"]')){
    try{
      const walk=(v,depth=0)=>{if(!v||typeof v!=='object'||depth>15)return;if(v['@type']==='Product'||Array.isArray(v['@type'])&&v['@type'].includes('Product'))objects.push(v);for(const x of Object.values(v))if(typeof x==='object'){if(Array.isArray(x))x.forEach(y=>walk(y,depth+1));else walk(x,depth+1);}};
      walk(JSON.parse(script.textContent));
    }catch{}
  }
  const product=objects[0];
  draft.name=String(product?.name||document.querySelector('meta[property="og:title"]')?.content||text(document.querySelector('h1'))||document.title||'');
  draft.supplier=String(product?.manufacturer?.name||product?.seller?.name||text(document.querySelector('[data-company-name], .company-name, .companyname'))||'');
  const promo=/新人|新客|券后|优惠券|补贴|限时|促销|折后/;
  const append=(name,offer={},selected=false)=>{
    let amount='';
    // AggregateOffer and price ranges are deliberately not treated as a selected SKU price.
    if(offer['@type']!=='AggregateOffer' && !promo.test(String(offer.name||'')) && /^\d+(\.\d+)?$/.test(String(offer.price||'')))amount=String(offer.price);
    draft.specs.push({spec:String(name||''),amount,currency:String(offer.priceCurrency||'CNY'),unit:'',weightGrams:'',quantity:'',selected,subcategoryName:''});
  };
  if(product){
    const variants=product.hasVariant;
    if(Array.isArray(variants))for(const variant of variants){const offers=Array.isArray(variant.offers)?variant.offers:[variant.offers];append(variant.name||variant.sku,offers[0]||{});}
    else {const offer=Array.isArray(product.offers)?product.offers[0]:product.offers;append('',offer||{});}
  }
  if(is1688){
    // Conservative DOM adapter. Accept explicit SKU labels only; never pair global price ranges with percentages.
    const candidates=[...document.querySelectorAll('[data-sku-name], .sku-item, .sku-item-wrapper, .sku-property-item')].slice(0,100);
    const specs=[];
    for(const el of candidates){
      const spec=el.getAttribute('data-sku-name')||el.getAttribute('title')||text(el.querySelector('.sku-name, .sku-item-name, .name'));
      if(!spec||specs.some(s=>s.spec===spec))continue;
      const priceEl=el.querySelector('[data-price], .sku-price, .price');
      const raw=priceEl?.getAttribute('data-price')||text(priceEl);
      const match=!promo.test(text(el)) && raw.match(/^(?:[¥￥]\s*)?(\d+(?:\.\d+)?)\s*(?:元)?$/);
      specs.push({spec,amount:match?match[1]:'',currency:'CNY',unit:'',weightGrams:'',quantity:el.getAttribute('data-min-order')||'',selected:el.getAttribute('aria-selected')==='true'||el.classList.contains('selected'),subcategoryName:''});
    }
    if(specs.length)draft.specs=specs;
  }
  if(!draft.specs.length)append('');
  return draft;
};
