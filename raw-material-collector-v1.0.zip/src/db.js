import {freshState} from './core.js';
const NAME='raw-material-collector';
const open = () => new Promise((resolve,reject) => {const req=indexedDB.open(NAME,1);req.onupgradeneeded=()=>req.result.createObjectStore('data');req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
export async function loadState(){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction('data','readonly'),req=tx.objectStore('data').get('state');let result;req.onsuccess=()=>{result=req.result;};tx.oncomplete=()=>{db.close();resolve(result||freshState());};tx.onerror=()=>{db.close();reject(tx.error);};});}
// Read, mutate and write within one transaction, so multiple tabs cannot overwrite each other.
export async function mutateState(fn){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction('data','readwrite'),store=tx.objectStore('data'),req=store.get('state');let state,error;req.onsuccess=()=>{try{state=req.result||freshState();fn(state);store.put(state,'state');}catch(e){error=e;tx.abort();}};tx.oncomplete=()=>{db.close();const channel=new BroadcastChannel(NAME);channel.postMessage('changed');channel.close();resolve(state);};tx.onabort=tx.onerror=()=>{db.close();reject(error||tx.error||new Error('保存失败'));};});}
export const subscribe = fn => {const channel=new BroadcastChannel(NAME);channel.onmessage=fn;return channel;};
