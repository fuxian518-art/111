export const uid = () => crypto.randomUUID();
export const today = () => new Date().toISOString().slice(0, 10);
export const freshState = () => ({version: 1, records: [], categories: [], sources: ['1688', '厂家官网', '国外品牌网站', '手动录入'], rates: {values: {CNY: 1}, date: '', fetchedAt: ''}});
export function safeURL(value) {
  try { const u = new URL(value); return ['http:', 'https:'].includes(u.protocol) ? u.href : ''; } catch { return ''; }
}
export function productKey(link) {
  if (!safeURL(link)) return '';
  const u = new URL(link);
  if (u.hostname === '1688.com' || u.hostname.endsWith('.1688.com')) {
    const id = u.pathname.match(/\/offer\/(\d+)\.html/)?.[1] || u.searchParams.get('offerId');
    if (id) return `1688:${id}`;
  }
  for (const key of [...u.searchParams.keys()]) if (/^(utm_|spm$|scm$|trace|tracelog$|clickid$)/i.test(key)) u.searchParams.delete(key);
  u.hash = ''; u.searchParams.sort(); return u.href;
}
export const normalize = s => String(s || '').normalize('NFKC').trim().toLowerCase().replace(/\s+/g, ' ');
export function duplicate(records, record) {
  const key = productKey(record.link);
  if (!key) return undefined;
  return records.find(r => r.id !== record.id && productKey(r.link) === key && normalize(r.spec) === normalize(record.spec));
}
export function kgPrice(quote) {
  if (quote?.amount === '' || quote?.amount == null) return null;
  const amount = Number(quote.amount), grams = Number(quote.weightGrams);
  if (!Number.isFinite(amount) || amount <= 0 || !Number.isFinite(grams) || grams <= 0) return null;
  return amount * 1000 / grams;
}
export function referencePrice(quote, rates) {
  const kg = kgPrice(quote); if (kg == null) return null;
  const rate = quote.currency === 'CNY' ? 1 : rates?.values?.[quote.currency];
  if (!Number.isFinite(rate) || rate <= 0) return null;
  return kg * rate;
}
export function bestQuote(record, source, rates) {
  if (!record.confirmed || !record.spec || !record.categoryId || !record.subcategoryId) return null;
  return (record[source] || []).map(q => ({quote: q, price: referencePrice(q, rates)})).filter(x => x.price != null).sort((a,b) => a.price-b.price)[0] || null;
}
export function selectRecords(state, filter) {
  let rows = state.records.filter(r => filter.view === 'trash' ? !!r.deletedAt : !r.deletedAt);
  if (filter.view === 'brand') rows = rows.filter(r => r.isBrand);
  if (filter.view === 'pending') rows = rows.filter(r => !r.confirmed || !r.categoryId || !r.subcategoryId || !r.spec);
  if (filter.categoryId) rows = rows.filter(r => r.categoryId === filter.categoryId);
  if (filter.subcategoryId) rows = rows.filter(r => r.subcategoryId === filter.subcategoryId);
  if (filter.source) rows = rows.filter(r => r.source === filter.source);
  const query = normalize(filter.query);
  if (query) rows = rows.filter(r => normalize([r.name,r.englishName,r.aliases,r.spec,r.supplier,r.brand,r.notes].join(' ')).includes(query));
  const priceSort = filter.sort === 'price' && !!filter.subcategoryId;
  return rows.sort((a,b) => {
    if (priceSort) {
      const pa=bestQuote(a,filter.quoteSource,state.rates)?.price ?? Infinity, pb=bestQuote(b,filter.quoteSource,state.rates)?.price ?? Infinity;
      if (pa !== pb) return pa-pb;
    }
    if (!!a.pinned !== !!b.pinned) return a.pinned ? -1 : 1;
    return b.createdAt.localeCompare(a.createdAt);
  });
}
export function updateRecord(previous, next) {
  const history = [...(previous.history || [])];
  for (const source of ['webQuotes','privateQuotes']) {
    if (JSON.stringify(previous[source] || []) !== JSON.stringify(next[source] || []) && previous[source]?.length) history.push({id:uid(), source, archivedAt:new Date().toISOString(), quotes:structuredClone(previous[source])});
  }
  return {...next, id:previous.id, createdAt:previous.createdAt, updatedAt:new Date().toISOString(), history};
}
function assertString(value, name, max=100000) { if (typeof value !== 'string' || value.length > max) throw new Error(`备份字段无效：${name}`); }
export function validateBackup(data) {
  if (data?.version !== 1 || !Array.isArray(data.records) || !Array.isArray(data.categories) || !Array.isArray(data.sources)) throw new Error('备份格式或版本不受支持');
  const ids=new Set(), cats=new Map();
  const unique = (id, set) => { assertString(id,'标识',200); if(!/^[A-Za-z0-9_-]+$/.test(id) || set.has(id)) throw new Error('备份包含空标识或重复标识'); set.add(id); };
  for (const c of data.categories) {
    unique(c.id,ids); assertString(c.name,'大类',200); if(!Array.isArray(c.children)) throw new Error('小类格式无效');
    const children=new Set(); for(const child of c.children){unique(child.id,ids); assertString(child.name,'小类',200);children.add(child.id);} cats.set(c.id,children);
  }
  const validateImages = images => {
    if(!Array.isArray(images)) throw new Error('截图格式无效');
    for(const img of images){assertString(img.name,'截图名',500);assertString(img.data,'截图',15000000);if(!/^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(img.data)) throw new Error('截图必须为有效的 PNG、JPEG、WebP 或 GIF 数据');}
  };
  const validateQuotes = quotes => {
    if(!Array.isArray(quotes)) throw new Error('报价格式无效');
    for(const q of quotes){
      for(const k of ['amount','weightGrams']) if(q[k] !== '' && q[k] != null && (!Number.isFinite(Number(q[k])) || Number(q[k])<=0)) throw new Error('报价金额和重量必须大于零');
      for(const k of ['currency','unit','quantity','date','notes']) assertString(q[k]??'',k);
      if(!/^[A-Z]{3}$/.test(q.currency)) throw new Error('币种无效'); validateImages(q.images||[]);
    }
  };
  for(const r of data.records){
    unique(r.id,ids); for(const k of ['name','spec','supplier','source','link','createdAt','updatedAt']) assertString(r[k],k);
    for(const k of ['englishName','aliases','brand','notes']) assertString(r[k]??'',k);
    if(!r.name.trim() || !Number.isFinite(Date.parse(r.createdAt)) || !Number.isFinite(Date.parse(r.updatedAt))) throw new Error('原料名称或日期无效');
    if(r.link && !safeURL(r.link)) throw new Error('备份中包含不安全的购买链接');
    if(r.categoryId && !cats.has(r.categoryId)) throw new Error('记录关联的大类不存在');
    if(r.subcategoryId && !cats.get(r.categoryId)?.has(r.subcategoryId)) throw new Error('记录关联的小类不存在');
    validateQuotes(r.webQuotes);validateQuotes(r.privateQuotes);validateImages(r.images||[]);
    if(!Array.isArray(r.history)) throw new Error('历史报价格式无效');
    for(const h of r.history){if(!['webQuotes','privateQuotes'].includes(h.source))throw new Error('历史来源无效');assertString(h.archivedAt,'历史日期');validateQuotes(h.quotes);}
  }
  for(const s of data.sources)assertString(s,'来源',200);
  if(!data.rates || typeof data.rates.values !== 'object' || !data.rates.values) throw new Error('汇率格式无效');
  for(const [c, rate] of Object.entries(data.rates.values)) if(!/^[A-Z]{3}$/.test(c) || !Number.isFinite(rate) || rate<=0) throw new Error('汇率数据无效');
  assertString(data.rates.date||'','汇率日期');assertString(data.rates.fetchedAt||'','汇率更新时间');
  return data;
}
