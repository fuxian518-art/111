chrome.action.onClicked.addListener(async tab => {
  let draft={link:tab.url||'',name:'',source:'',supplier:'',specs:[],warning:''};
  try {
    if(!tab.id || !/^https?:/.test(tab.url||'')) throw new Error('此页面不允许读取，请手动填写。');
    await chrome.scripting.executeScript({target:{tabId:tab.id},files:['src/extractor.js']});
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>globalThis.__rawMaterialExtract()});
    draft=results[0]?.result||draft;
  } catch(error){draft.warning=`页面读取失败，可手动填写。${error.message||''}`;}
  const key=crypto.randomUUID();
  await chrome.storage.session.set({[key]:draft});
  await chrome.windows.create({url:chrome.runtime.getURL(`index.html?capture=${key}`),type:'popup',width:1100,height:820});
});
